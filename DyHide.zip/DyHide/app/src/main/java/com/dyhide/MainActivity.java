package com.dyhide;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;

public class MainActivity extends Activity {
    static final int BG = 0xFFF2F3F7, CARD = 0xFFFFFFFF, INK = 0xFF15181F, SUB = 0xFF7C8394,
            ACCENT = 0xFF3B6CF6, OFF = 0xFFC8CCD6;
    static final long SLIDE = 300, FADE = 240;
    static final String[] TABS = {"规则", "外观", "状态"};

    private interface Fill { void fill(LinearLayout col); }

    private static final class Page {
        final View view; final String crumb;
        Page(View v, String c) { view = v; crumb = c; }
    }

    private SharedPreferences cfg;
    private float density;
    private FrameLayout content;
    private final TextView[] tabViews = new TextView[3];
    private final List<List<Page>> stacks = new ArrayList<>();
    private final List<Runnable> refreshers = new ArrayList<>();
    private int tab = 0;
    private boolean busy;

    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    private SharedPreferences prefs() {
        try {
            return getSharedPreferences("config", MODE_WORLD_READABLE);
        } catch (Throwable t) {
            return getSharedPreferences("config", MODE_PRIVATE);
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        // 临时诊断：应用崩溃时把堆栈写到 /sdcard/Android/data/com.dyhide/files/crash.txt
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try (FileWriter w = new FileWriter(new File(getExternalFilesDir(null), "crash.txt"))) {
                w.write(Log.getStackTraceString(e));
            } catch (java.io.IOException ignored) { }
            prev.uncaughtException(t, e);
        });
        cfg = prefs();
        density = getResources().getDisplayMetrics().density;
        for (int i = 0; i < 3; i++) stacks.add(new ArrayList<Page>());
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));

        final LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(CARD);
        bar.setElevation(dp(10));
        if (Build.VERSION.SDK_INT >= 28) {
            bar.setOutlineAmbientShadowColor(0x1A000000);
            bar.setOutlineSpotShadowColor(0x26000000);
        }
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView t = text(TABS[i], 15, SUB, false);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(16), 0, dp(16));
            t.setOnClickListener(v -> switchTab(idx));
            bar.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            tabViews[i] = t;
        }
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(0, ins.getSystemWindowInsetTop(), 0, 0);
            bar.setPadding(0, 0, 0, ins.getSystemWindowInsetBottom());
            return ins;
        });
        setContentView(root);

        Page p = rootPage(0);
        stacks.get(0).add(p);
        content.addView(p.view, new FrameLayout.LayoutParams(-1, -1));
        styleTabs();
    }

    // ---------- 导航：右侧滑入/反向滑出 300ms，底部标签淡入淡出 ----------
    private Page top(int t) {
        List<Page> st = stacks.get(t);
        return st.get(st.size() - 1);
    }

    private void push(final Page p) {
        if (busy) return;
        busy = true;
        List<Page> st = stacks.get(tab);
        final Page old = st.get(st.size() - 1);
        st.add(p);
        content.addView(p.view, new FrameLayout.LayoutParams(-1, -1));
        final float w = content.getWidth();
        p.view.setTranslationX(w);
        p.view.animate().translationX(0).setDuration(SLIDE).setInterpolator(new DecelerateInterpolator()).start();
        old.view.animate().translationX(-w * 0.25f).alpha(0.6f).setDuration(SLIDE)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    old.view.setVisibility(View.GONE);
                    old.view.setTranslationX(0);
                    old.view.setAlpha(1f);
                    busy = false;
                }).start();
    }

    /** 保留前 keep 个页面，其余弹出（最上面一页向右滑出）。 */
    private void popTo(int keep) {
        List<Page> st = stacks.get(tab);
        if (busy || st.size() <= keep || keep < 1) return;
        busy = true;
        final float w = content.getWidth();
        final Page topPage = st.remove(st.size() - 1);
        while (st.size() > keep) content.removeView(st.remove(st.size() - 1).view);
        Page target = st.get(st.size() - 1);
        target.view.setVisibility(View.VISIBLE);
        target.view.setTranslationX(-w * 0.25f);
        target.view.setAlpha(0.6f);
        target.view.animate().translationX(0).alpha(1f).setDuration(SLIDE)
                .setInterpolator(new DecelerateInterpolator()).start();
        topPage.view.animate().translationX(w).setDuration(SLIDE)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    content.removeView(topPage.view);
                    busy = false;
                }).start();
    }

    private void switchTab(int to) {
        if (to == tab || busy) return;
        busy = true;
        final View from = top(tab).view;
        tab = to;
        styleTabs();
        if (stacks.get(to).isEmpty()) stacks.get(to).add(rootPage(to));
        final View in = top(to).view;
        if (in.getParent() == null) content.addView(in, new FrameLayout.LayoutParams(-1, -1));
        in.setVisibility(View.VISIBLE);
        in.setAlpha(0f);
        in.setTranslationX(0);
        from.animate().alpha(0f).setDuration(FADE).start();
        in.animate().alpha(1f).setDuration(FADE).withEndAction(() -> {
            from.setVisibility(View.GONE);
            from.setAlpha(1f);
            busy = false;
        }).start();
    }

    private void styleTabs() {
        for (int i = 0; i < 3; i++) {
            tabViews[i].setTextColor(i == tab ? ACCENT : SUB);
            tabViews[i].setTypeface(i == tab ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        }
    }

    @Override
    public void onBackPressed() {
        if (busy) return;
        List<Page> st = stacks.get(tab);
        if (st.size() > 1) popTo(st.size() - 1);
        else super.onBackPressed();
    }

    // ---------- 页面 ----------
    private Page rootPage(int t) {
        if (t == 0) return rulesRoot();
        return t == 1 ? lookPage() : statePage();
    }

    private Page rulesRoot() {
        List<String> path = new ArrayList<>(Arrays.asList("规则"));
        return page("规则", "隐藏规则", path, col -> {
            col.addView(text("选择要隐藏的界面元素，改动约 1 秒内在抖音生效，无需重启。", 14, SUB, false), lp(0, 12, 0, 0));
            LinkedHashSet<String> groups = new LinkedHashSet<>();
            for (Rules.R r : Rules.ALL) groups.add(r.group);
            for (final String g : groups) {
                LinearLayout body = cardBody();
                addRow(body, navRow(g, summary(g, null), () -> push(groupPage(g))));
                addGroup(col, wrapCard(body), 40);
            }
        });
    }

    private Page groupPage(final String g) {
        List<String> path = new ArrayList<>(Arrays.asList("规则", g));
        return page(g, g, path, col -> {
            LinearLayout body = cardBody();
            for (Rules.R r : Rules.ALL) {
                if (r.group.equals(g) && r.sub == null) addRow(body, switchRow(r.label, r.key(), true));
            }
            if (body.getChildCount() > 0) addGroup(col, wrapCard(body), 12);
            LinkedHashSet<String> subs = new LinkedHashSet<>();
            for (Rules.R r : Rules.ALL) if (r.group.equals(g) && r.sub != null) subs.add(r.sub);
            for (final String s : subs) {
                LinearLayout sb = cardBody();
                addRow(sb, navRow(s, summary(g, s), () -> push(subPage(g, s))));
                addGroup(col, wrapCard(sb), 40);
            }
        });
    }

    private Page subPage(String g, String s) {
        List<String> path = new ArrayList<>(Arrays.asList("规则", g, s));   // 三层：顶部显示可点击路径
        return page(s, s, path, col -> {
            LinearLayout body = cardBody();
            for (Rules.R r : Rules.ALL) {
                if (g.equals(r.group) && s.equals(r.sub)) addRow(body, switchRow(r.label, r.key(), true));
            }
            addGroup(col, wrapCard(body), 12);
        });
    }

    private Page lookPage() {
        List<String> path = new ArrayList<>(Arrays.asList("外观"));
        return page("外观", "外观", path, col -> {
            LinearLayout a = cardBody();
            addRow(a, switchRow("底栏背景全透明", "nav_transparent", true));
            addRow(a, switchRow("视频铺满到底栏下方", "extend_feed", true));
            addGroup(col, wrapCard(a), 12);
            col.addView(text("只去掉底栏背景，图标和文字保持不透明。铺满开关用于让视频显示在透明底栏后面。", 13, SUB, false), lp(0, 12, 0, 0));
            LinearLayout b = cardBody();
            addRow(b, switchRow("顶部标签隐藏后居中", "center_tabs", true));
            addGroup(col, wrapCard(b), 40);
        });
    }

    private Page statePage() {
        List<String> path = new ArrayList<>(Arrays.asList("状态"));
        return page("状态", "状态", path, col -> {
            LinearLayout a = cardBody();
            final TextView total = num("");
            final TextView enabled = num("");
            addRow(a, valueRow("规则总数", total));
            addRow(a, valueRow("已启用", enabled));
            Runnable rf = () -> {
                int n = 0, e = 0;
                for (Rules.R r : Rules.ALL) { n++; if (cfg.getBoolean(r.key(), true)) e++; }
                total.setText(String.valueOf(n));
                enabled.setText(String.valueOf(e));
            };
            refreshers.add(rf);
            rf.run();
            addGroup(col, wrapCard(a), 12);
            LinearLayout b = cardBody();
            addRow(b, switchRow("调试：导出控件树和状态文件", "dump", true));
            addGroup(col, wrapCard(b), 40);
            col.addView(text("文件保存在 /sdcard/Android/data/com.ss.android.ugc.aweme/files/ 下的 dyhide_status.txt 和 viewdump_*.txt。测试结束后可关闭。", 13, SUB, false), lp(0, 12, 0, 0));
        });
    }

    private Page page(String crumb, String title, List<String> path, Fill fill) {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipToPadding(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sv.setBackgroundColor(BG);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setClipChildren(false);
        col.setClipToPadding(false);
        col.setPadding(dp(20), dp(24), dp(20), dp(56));
        sv.addView(col, new ViewGroup.LayoutParams(-1, -2));
        if (path.size() >= 3) col.addView(crumbs(path), lp(0, 0, 0, 12));
        col.addView(text(title, 30, INK, true), lp(0, 0, 0, 0));
        fill.fill(col);
        return new Page(sv, crumb);
    }

    private View crumbs(final List<String> path) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < path.size(); i++) {
            final int idx = i;
            boolean last = i == path.size() - 1;
            TextView c = text(path.get(i), 14, last ? SUB : ACCENT, false);
            if (!last) {
                c.setPadding(0, dp(8), 0, dp(8));
                c.setOnClickListener(v -> popTo(idx + 1));
            }
            row.addView(c);
            if (!last) row.addView(text("  ›  ", 14, SUB, false));
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        return hs;
    }

    // ---------- 组件 ----------

    private TextView summary(final String g, final String s) {
        final TextView t = num("");
        t.setTextSize(13);
        t.setTextColor(SUB);
        Runnable rf = () -> {
            int n = 0, e = 0;
            for (Rules.R r : Rules.ALL) {
                if (!r.group.equals(g)) continue;
                if (s != null && !s.equals(r.sub)) continue;
                n++;
                if (cfg.getBoolean(r.key(), true)) e++;
            }
            t.setText("已隐藏 " + e + " / " + n + " 项");
        };
        refreshers.add(rf);
        rf.run();
        return t;
    }

    private TextView num(String s) {
        TextView t = text(s, 16, INK, false);
        t.setFontFeatureSettings("tnum");   // 数字等宽
        return t;
    }

    private void refreshAll() {
        for (Runnable r : refreshers) r.run();
    }

    private View navRow(String name, TextView sub, final Runnable go) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(text(name, 18, INK, true));
        left.addView(sub, lp(0, 4, 0, 0));
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(text("›", 26, SUB, false));
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tv, true);
        row.setBackgroundResource(tv.resourceId);
        row.setClickable(true);
        row.setOnClickListener(v -> go.run());
        return row;
    }

    private View valueRow(String label, TextView value) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(text(label, 16, INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(value);
        return row;
    }

    private Switch switchRow(String label, final String key, boolean def) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextSize(16);
        s.setTextColor(INK);
        s.setMinHeight(dp(44));
        s.setChecked(cfg.getBoolean(key, def));
        s.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
        s.setTrackTintList(new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}}, new int[]{ACCENT, OFF}));
        s.setOnCheckedChangeListener((v, on) -> {
            cfg.edit().putBoolean(key, on).apply();
            refreshAll();
        });
        return s;
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.15f);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout cardBody() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(20), dp(16), dp(20), dp(16));
        return c;
    }

    /** 柔和的三层阴影（紧、中、宽）代替边框：三个同尺寸的白色圆角底板，各自不同的 elevation。 */
    private View wrapCard(LinearLayout body) {
        FrameLayout w = new FrameLayout(this);
        w.setClipChildren(false);
        w.setClipToPadding(false);
        shadowLayer(w, 2, 0x14000000, 0x1F000000);
        shadowLayer(w, 8, 0x0F000000, 0x1A000000);
        shadowLayer(w, 18, 0x0A000000, 0x14000000);
        body.setElevation(dp(19));
        w.addView(body, new FrameLayout.LayoutParams(-1, -2));
        return w;
    }

    private void shadowLayer(FrameLayout w, float elev, int amb, int spot) {
        View v = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setColor(CARD);
        d.setCornerRadius(dp(20));
        v.setBackground(d);
        v.setElevation(dp(elev));
        if (Build.VERSION.SDK_INT >= 28) {
            v.setOutlineAmbientShadowColor(amb);
            v.setOutlineSpotShadowColor(spot);
        }
        w.addView(v, new FrameLayout.LayoutParams(-1, -1));
    }

    /** 同组元素间距 12dp；不同组之间 40dp。 */
    private void addRow(LinearLayout body, View v) {
        body.addView(v, lp(0, body.getChildCount() == 0 ? 0 : 12, 0, 0));
    }

    private void addGroup(LinearLayout col, View v, int topDp) {
        col.addView(v, lp(0, topDp, 0, 0));
    }

    private LinearLayout.LayoutParams lp(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(float v) {
        return Math.round(v * density);
    }
}
