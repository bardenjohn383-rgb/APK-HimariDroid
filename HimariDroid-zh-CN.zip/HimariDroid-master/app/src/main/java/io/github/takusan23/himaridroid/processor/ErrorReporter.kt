package io.github.takusan23.himaridroid.processor

import android.content.Context
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.contentValuesOf
import io.github.takusan23.himaridroid.data.EncoderParams
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** エンコード失敗時に、原因調査用のレポートを Download フォルダへ保存する */
object ErrorReporter {

    /**
     * レポートを Download フォルダに保存する
     *
     * @return 保存したファイル名。保存に失敗した場合は null
     */
    suspend fun save(
        context: Context,
        inputUri: Uri,
        encoderParams: EncoderParams,
        throwable: Throwable
    ): String? = withContext(Dispatchers.IO) {
        val report = buildReport(context, inputUri, encoderParams, throwable)
        val timeText = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "HimariDroid_error_$timeText.txt"
        runCatching {
            val resolver = context.contentResolver
            val contentValues = contentValuesOf(
                MediaStore.MediaColumns.DISPLAY_NAME to fileName,
                MediaStore.MediaColumns.MIME_TYPE to "text/plain",
                MediaStore.MediaColumns.RELATIVE_PATH to Environment.DIRECTORY_DOWNLOADS
            )
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { it.write(report.toByteArray()) }
                fileName
            } else {
                null
            }
        }.getOrNull()
    }

    private fun buildReport(
        context: Context,
        inputUri: Uri,
        encoderParams: EncoderParams,
        throwable: Throwable
    ): String = buildString {
        appendLine("== HimariDroid error report ==")
        appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})")
        appendLine("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
        appendLine("Build: ${Build.DISPLAY}")
        appendLine()

        appendLine("== Encoder params ==")
        appendLine(encoderParams.toString())
        appendLine()

        appendLine("== Input tracks ==")
        val inputMimeTypeList = mutableListOf<String>()
        runCatching {
            val extractor = MediaExtractor()
            try {
                context.contentResolver.openFileDescriptor(inputUri, "r")?.use { extractor.setDataSource(it.fileDescriptor) }
                for (index in 0 until extractor.trackCount) {
                    val format = extractor.getTrackFormat(index)
                    appendLine("track $index: $format")
                    format.getString(MediaFormat.KEY_MIME)?.let { inputMimeTypeList += it }
                }
            } finally {
                extractor.release()
            }
        }.onFailure { appendLine("failed to read input: $it") }
        appendLine()

        appendLine("== Codecs (input video + output video) ==")
        val targetMimeTypeList = (inputMimeTypeList.filter { it.startsWith("video/") } + encoderParams.codecContainerType.videoCodec).distinct()
        runCatching {
            MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.forEach { info ->
                info.supportedTypes.filter { it in targetMimeTypeList }.forEach { mimeType ->
                    val profiles = runCatching {
                        info.getCapabilitiesForType(mimeType).profileLevels.joinToString { "${it.profile}/${it.level}" }
                    }.getOrNull()
                    val kind = if (info.isEncoder) "ENC" else "DEC"
                    appendLine("$kind ${info.name} [$mimeType] hw=${info.isHardwareAccelerated} sw=${info.isSoftwareOnly} alias=${info.isAlias} profile/level=$profiles")
                }
            }
        }.onFailure { appendLine("failed to list codecs: $it") }
        appendLine()

        appendLine("== Exception ==")
        val stringWriter = StringWriter()
        throwable.printStackTrace(PrintWriter(stringWriter))
        appendLine(stringWriter.toString())
    }
}
